package com.cognizant.util;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClientConfig cfg = new DefaultClientConfig();
		Client client = Client.create(cfg);
		WebResource service = client.resource("http://localhost:8080/Day8ImageDemo");
		ClientResponse response = 
				service.path("rest").path("/ImageService/getData/360654;eventName=Ananthi")
				.type("text/plain")
				.get(ClientResponse.class);
		System.out.println(response.getCookies());
		System.out.println(response);
	}

}
