package com.cognizant.testcases;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.dao.EventManager;
import com.cognizant.entities.Event;
import com.cognizant.entities.EventKey;

public class EventTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		EventManager eventmanager = new EventManager();
		EventKey eventkey = new EventKey();
		eventkey.setEventId(4);
		eventkey.setTrainerId(200);
		
		Event event = new Event();
		event.setDuration(3);
		event.setEventId(eventkey);
		event.setEventName("webservice");
		event.setLocation("Chennai");
		assertTrue(eventmanager.AddEvent(event));
	//	fail("Not yet implemented");
	}

}
