package com.cognizant.utility;

import java.util.Scanner;

import com.cognizant.dao.EventManager;
import com.cognizant.dao.RoomManager;
import com.cognizant.entities.Event;
import com.cognizant.entities.EventKey;
import com.cognizant.entities.Room;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	RoomManager roomManager = new RoomManager();
		/*Room room = new Room();
		room.setCapacity(25);
		room.setLocation("TCO");
		room.setProjector_Avl(false);
		room.setSystems_Avl(true);
		if(roomManager.AddRoom(room))
		{
			System.out.println("Record Added");
		}
		*/
/*		if(roomManager.UpdateRoom(6))
		{
			System.out.println("Updated");
		}
*/
		/*for(Room room:roomManager.GetAllRooms())
		{
			System.out.print(room.getCapacity()+"\t");
			System.out.println(room.getLocation());
			
		}
		*/
		/*Scanner scanner = new Scanner(System.in);
		System.out.println("Enter room no1");
		int roomno1 = scanner.nextInt();
		System.out.println("Enter room no2");
		int roomno2 = scanner.nextInt();
		
		
		roomManager.roomEvit_Clear(roomno1, roomno2);
		*/
	/*	Scanner scanner = new Scanner(System.in);
		System.out.println("Enter room no");
		int roomno = scanner.nextInt();
		
		if(roomManager.SessionClose(roomno))
		{
			System.out.println("session close");
		}
	*/	
		
		EventManager eventmanager = new EventManager();
		EventKey eventkey = new EventKey();
		eventkey.setEventId(1);
		eventkey.setTrainerId(200);
		
		Event event = new Event();
		event.setDuration(3);
		event.setEventId(eventkey);
		event.setEventName("Hibernate");
		event.setLocation("Chennai");
		eventmanager.AddEvent(event);
	}

}
