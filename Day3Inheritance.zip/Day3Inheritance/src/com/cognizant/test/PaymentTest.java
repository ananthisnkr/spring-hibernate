package com.cognizant.test;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.dao.DaoMananger;
import com.cognizant.entities.Address;
import com.cognizant.entities.CreditCard;
import com.cognizant.entities.DebitCard;
import com.cognizant.entities.Employee;
import com.cognizant.entities.Manager;
import com.cognizant.entities.Payment;
import com.cognizant.entities.Person;

public class PaymentTest {

	private DaoMananger dao;
	@Before
	public void setUp() throws Exception {
		
		dao = new DaoMananger();
	}

	@After
	public void tearDown() throws Exception {
	}

	/*@Test
	public void PaymentObjTest() {
		
		
		Payment pay = new Payment();
		pay.setAmount(1500);
		pay.setDOT(new Date(116,6,26));
		
		assertTrue(dao.addPayment(pay));
		
	//	CreditCard cc = new CreditCard();
	//	DebitCard dc = new DebitCard();
		
		//fail("Not yet implemented");
	}
	*/
	/*@Test
	public void creditCardObjTest(){
		
		CreditCard cc = new CreditCard();
		cc.setcExpiryDate(new Date(119,5,22));
		cc.setcName("Platinum");
		cc.setCreditCardNo(1234567890);
		cc.setCvv(345);
		cc.setEMI(true);
		cc.setAmount(3000);
		cc.setDOT(new Date(116,7,3));
		assertTrue(dao.addCreditPayment(cc));
		
		
	}
	*/
	/*@Test
	public void paymentObjectTest()
	{
		Payment pay = new Payment();
		pay.setCustomerId(1234);
		pay.setAmount(1700);
		pay.setDOT(new Date(116,6,26));
		
		assertTrue(dao.addPayment(pay));
		
		CreditCard cc = new CreditCard();
		cc.setCustomerId(234);
 		cc.setcName("Platinum");
		cc.setCreditCardNo(1234567890);
		cc.setCvv(345);
		cc.setEMI(true);
		cc.setAmount(3000);
		cc.setDOT(new Date(116,7,3));
		assertTrue(dao.addCreditPayment(cc));
		
	}
	*/
/*	@Test
	public void personTest()
	{
		Person person = new Person();
		person.setName("Sree");
		
		Address addr = new Address();
		addr.setCity("Chennai");
		addr.setState("TamilNadu");
		addr.setStreetName("ElimNagar");
		
		assertTrue(dao.addPerson(person, addr));
		
	}
*/	

	/*@Test
	public void employeeTest()
	{
		Employee emp = new Employee();
		emp.setEmpNo(123);
		emp.setLocation("Chennai");
		emp.setProject("DFS");
		emp.setName("Saanvika");
		Address addr = new Address();
		addr.setCity("Chennai");
		addr.setState("TamilNadu");
		addr.setStreetName("Selviger");
		emp.setAddr(addr);
		assertTrue(dao.addEmployee(emp, addr));
		
	}*/
	
	/*@Test
	public void managerTest()
	{
		Manager mgr = new Manager();
		mgr.setNoOfProjects(6);
		mgr.setLeaveApproval(true);
		mgr.setEmpNo(556);
		mgr.setLocation("CRC");
		mgr.setProject("DNI");
		mgr.setName("Sree");
		Address addr = new Address();
		addr.setCity("Tuty");
		addr.setState("TamilNadu");
		addr.setStreetName("SB colony");
		mgr.setAddr(addr);
		assertTrue(dao.addManager(mgr, addr));
		
		
	}*/
	
	@Test
	public void getManagerTest()
	{
		
		
		for (Manager manager: dao.getManagers())
		{
			System.out.print(manager.getAadharNo()+"\t");
			System.out.print(manager.getName()+"\t");
			System.out.print(manager.getAddr().getCity()+"\t");
			System.out.print(manager.getAddr().getState()+"\t");
			System.out.print(manager.getAddr().getStreetName()+"\t");
			System.out.print(manager.getEmpNo()+"\t");
			System.out.print(manager.getLocation()+"\t");
			System.out.print(manager.getNoOfProjects()+"\t");
			System.out.print(manager.getProject()+"\t");
			System.out.println(manager.isLeaveApproval());
		}
	}
}
