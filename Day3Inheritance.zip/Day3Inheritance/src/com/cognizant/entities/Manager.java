package com.cognizant.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Mananger")
public class Manager extends Employee{
	
	@Column(name="No_Of_Projects")
	private int noOfProjects;
	
	@Column(name="Leave_Approval")
	private boolean leaveApproval;
	
	public int getNoOfProjects() {
		return noOfProjects;
	}
	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}
	public boolean isLeaveApproval() {
		return leaveApproval;
	}
	public void setLeaveApproval(boolean leaveApproval) {
		this.leaveApproval = leaveApproval;
	}
	
	

}
