package com.cognizant.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Employee")
@PrimaryKeyJoinColumn(name="Aadhar_No", referencedColumnName="Aadhar_No")
public class Employee extends Person {

	@Column(name="Employee_No")
	private int empNo;
	
	@Column(name="Project")
	private String project;
	
	@Column(name="Location")
	private String location;
	
	
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}
