package com.cognizant.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/** Table per inheritance **/
/*@Entity
@DiscriminatorValue(value="DebitcardObj")
*/
/** Table per class **/

@Entity
@Table(name="DebitCard")
public class DebitCard extends Payment{
	
	@Column(name="DebitCard_No")
	private long debitCardNo;
	
	@Column(name="DVV")
	private int dvv;
	
	@Column(name="DC_Name")
	private String dName;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DC_Exp_Date")
	private Date dExpiryDate;
	
	public long getDebitCardNo() {
		return debitCardNo;
	}
	public void setDebitCardNo(long debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public int getDvv() {
		return dvv;
	}
	public void setDvv(int dvv) {
		this.dvv = dvv;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public Date getdExpiryDate() {
		return dExpiryDate;
	}
	public void setdExpiryDate(Date dExpiryDate) {
		this.dExpiryDate = dExpiryDate;
	}
	

}
