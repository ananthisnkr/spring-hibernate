package com.cognizant.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/** Table per hierarchy **/
/*@Entity
@DiscriminatorValue(value="CreditcardObj")
*/

/** Table per class **/

@Entity
@Table(name="CreditCard")
public class CreditCard extends Payment{
	
	@Column(name="CreditCard_No")	
	private long creditCardNo;
	
	@Column(name="CVV")
	private int cvv;
	
	@Column(name="CC_Name")
	private String cName;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CC_EXP_Date")
	private Date cExpiryDate;
	
	@Column(name="EMI")
	private boolean EMI;
	
	public long getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(long creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public Date getcExpiryDate() {
		return cExpiryDate;
	}
	public void setcExpiryDate(Date cExpiryDate) {
		this.cExpiryDate = cExpiryDate;
	}
	public boolean isEMI() {
		return EMI;
	}
	public void setEMI(boolean eMI) {
		EMI = eMI;
	}
	

}
