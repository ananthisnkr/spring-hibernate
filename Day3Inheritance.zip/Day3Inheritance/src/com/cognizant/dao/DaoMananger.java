package com.cognizant.dao;

import java.util.List;

import javax.persistence.criteria.From;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Address;
import com.cognizant.entities.CreditCard;
import com.cognizant.entities.Employee;
import com.cognizant.entities.Manager;
import com.cognizant.entities.Payment;
import com.cognizant.entities.Person;
import com.cognizant.resources.HibernateUtil;

public class DaoMananger {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoMananger()
	{
		factory= HibernateUtil.GetFactory();
	}
	
	public boolean addPayment(Payment payment)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(payment);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			
		}
		session.close();
		return status;
	}
	
	public boolean addCreditPayment(CreditCard cc)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(cc);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			
		}
		session.close();
		return status;
	
	}
	
	public boolean addPerson(Person person, Address address)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(address);
			person.setAddr(address);
			session.save(person);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			
		}
		session.close();
		return status;
	}
	
	public boolean addEmployee(Employee emp, Address addr)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
						
			session.save(addr);
			emp.setAddr(addr);
			session.save(emp);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			
		}
		session.close();
		return status;
		
	}
	
	public boolean addManager(Manager mgr, Address addr)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
						
			session.save(addr);
			mgr.setAddr(addr);
			session.save(mgr);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			
		}
		session.close();
		return status;
		
	}
	
	public List<Manager> getManagers()
	{
		session = factory.openSession();
		session.beginTransaction();
		return session.createQuery("from Manager").list();
					
		
	}
}
