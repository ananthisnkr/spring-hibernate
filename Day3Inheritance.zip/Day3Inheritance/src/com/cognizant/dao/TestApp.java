package com.cognizant.dao;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import com.cognizant.entities.Address;
import com.cognizant.entities.Payment;
import com.cognizant.entities.Person;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoMananger dao = new DaoMananger();
		/*Payment pay = new Payment();
		pay.setAmount(1500);
		pay.setDOT(new Date(116,6,26));
		
		assertTrue(dao.addPayment(pay));
*/
		Person person = new Person();
		person.setName("Sree");
		
		Address addr = new Address();
		addr.setCity("Chennai");
		addr.setState("TamilNadu");
		addr.setStreetName("ElimNagar");
		
		assertTrue(dao.addPerson(person, addr));
			
	
	}

}
