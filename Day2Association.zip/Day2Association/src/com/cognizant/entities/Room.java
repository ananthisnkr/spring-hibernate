package com.cognizant.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Roomnew")
public class Room {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Room_No")
	private int roomNo;
	
	@Column(name="Room_Name")
	private String roomName;
	
	@OneToOne
	@JoinColumn(name="Event_Details")
	private Event event;
	
	@OneToMany(mappedBy="room",cascade=CascadeType.ALL)
	private List<Participant> participantList;
	
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	public List<Participant> getParticipantList() {
		return participantList;
	}
	public void setParticipantList(List<Participant> participantList) {
		this.participantList = participantList;
	}
	
	
}
