package com.cognizant.entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Book")
public class Book {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ISBNNO")
	private int ISBN;
	
	@Column(name="Name")
	private String name;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DOP")
	private Date DOP;
	
	@OneToOne(mappedBy="book", cascade=CascadeType.ALL)
	private Author author;
	
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int lSBN) {
		ISBN = lSBN;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDOP() {
		return DOP;
	}
	public void setDOP(Date dOP) {
		DOP = dOP;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	
}
