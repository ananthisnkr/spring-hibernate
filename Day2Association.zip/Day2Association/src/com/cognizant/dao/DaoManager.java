package com.cognizant.dao;

import java.util.List;












import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Session;

import com.cognizant.entities.Address;
import com.cognizant.entities.Author;
import com.cognizant.entities.Book;
import com.cognizant.entities.Course;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Event;
import com.cognizant.entities.Participant;
import com.cognizant.entities.Player;
import com.cognizant.entities.Room;
import com.cognizant.entities.Team;
import com.cognizant.entities.Trainee;
import com.cognizant.resources.HibernateUtil;

public class DaoManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoManager()
	{
		factory = HibernateUtil.GetFactory();
	}
	
	public boolean addCustomer_Address(Customer customer, Address address)
	{
		
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.persist(address);
			customer.setAddress(address);
			session.persist(customer);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();
		return status;
	}
	
	public Query getAll()
	{
		session = factory.openSession();
		return session.createQuery("select cust.customerId, cust.name, addr.street, addr.city from Customer cust inner join cust.address addr");
	}
	
	public boolean updateCustomer(int custid, String street)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			Customer cust = (Customer) session.get(Customer.class, custid);
			Address addr = new Address();
			addr.setStreet(street);
			cust.setAddress(addr);
			session.update(cust);
			session.getTransaction().commit();
			status = true;
			
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status = false;
		}
		
		session.close();
		return status;
	}
	
	public boolean addBookAuthor(Book book, Author author)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			author.setBook(book);
			book.setAuthor(author);
			session.save(book);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();
		return status;
	}
	
	public boolean addTeamPlayer(Team team, List<Player> playerList)
	{
		
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			team.setPlayers(playerList);
			session.save(team);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();

		return status;
	}
	
	public List<Team> getAllTeamPlayers()
	{
		session= factory.openSession();
		return session.createQuery("from Team").list();
		
	}
	
	public boolean addTraineeCourse(List<Trainee> traineeList, List<Course> courseList)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			for(Trainee trainee:traineeList){
				trainee.setCourse(courseList);
				session.save(trainee);
			}
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();

		return status;		
	}
	
	public boolean addRoomEvent(Room room,Event event)
	{
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(event);
			room.setEvent(event);
			session.save(room);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();

		return status;		
		
	}
	
	public boolean addParticipants(Room room, List<Participant> pList)
	{
		Participant par = new Participant();
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			
			par.setRoom(room);
			room.setParticipantList(pList);
			session.save(room);
			
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
			status= false;
		}
		session.close();

		return status;		

	}
}
