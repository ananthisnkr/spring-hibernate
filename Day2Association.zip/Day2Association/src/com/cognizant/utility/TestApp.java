package com.cognizant.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cognizant.dao.DaoManager;
import com.cognizant.entities.Address;
import com.cognizant.entities.Author;
import com.cognizant.entities.Book;
import com.cognizant.entities.Course;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Event;
import com.cognizant.entities.Participant;
import com.cognizant.entities.Player;
import com.cognizant.entities.Room;
import com.cognizant.entities.Team;
import com.cognizant.entities.Trainee;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
		
			DaoManager dao = new DaoManager();
			/*Address address = new Address();
			address.setStreet("Rajaji Street");
			address.setCity("Chennai");
			Customer customer = new Customer();
			customer.setName("Sree");
			customer.setDob(new Date(116,8,29));
			if(dao.addCustomer_Address(customer, address))
			{
				System.out.println("Added Successfully");
			}
			else
			{
				System.out.println("Couldnot add");
			}
			*/
			
			//Iterable itr = (Iterable) dao.getAll().iterator();5
			
			Iterator itr = dao.getAll().iterate();
			System.out.println("Customer Id   Name    Street     city");
			while(itr.hasNext())
			{
				//System.out.println(itr.next());
				Object[] obj= (Object[]) itr.next();
				System.out.println(obj[0]+"\t"+ obj[1]+"\t"+obj[2]+"\t"+obj[3]);
			}
			
			/*System.out.println("enter cust id");
			Scanner in = new Scanner(System.in);
			int custid = in.nextInt();
			System.out.println("enter street name");
			String street = in.next();
			if(dao.updateCustomer(custid, street))
			{
				System.out.println("updated..");
			}
			else
			{
				System.out.println("not updated");
			}*/
			
			/*Book book = new Book();
			book.setName("Java");
			book.setDOP(new Date(116,4,20));
			Author author = new Author();
			author.setName("Gosling");
			if(dao.addBookAuthor(book, author))
			{
				System.out.println("Added Successfully");
			}
			else
			{
				System.out.println("Something wrong");
			}*/
			
			/*
			Team team = new Team();
			team.setName("RCB");
			List<Player> players = new ArrayList<Player>();
			Player player1 = new Player();
			player1.setPlayerName("gayle");
			player1.setTeam(team);
			Player player2 = new Player();
			player2.setPlayerName("raina");
			player2.setTeam(team);
			
			players.add(player1);
			players.add(player2);
			if(dao.addTeamPlayer(team, players))
			{
				System.out.println("Addes successfully");
			}
			else
			{
				System.out.println("Something went wrong");
			}
			*/
			
			/*for(Team team : dao.getAllTeamPlayers())
			{
				System.out.println(team.getName());
				for(Player player: team.getPlayers())
				{
					System.out.println(player.getPlayerName());
				}
			}*/
/*			List<Trainee> traineeList = new ArrayList<Trainee>();
			List<Course> courseList = new ArrayList<Course>();
			Trainee trainee;
			trainee = new Trainee();
			trainee.setTraineeName("Sanjay");
			traineeList.add(trainee);
			trainee = new Trainee();
			trainee.setTraineeName("Sree");
			traineeList.add(trainee);
			trainee = new Trainee();
			trainee.setTraineeName("Sam");
			traineeList.add(trainee);	
			
			Course course = new Course();
			course.setCourseName("Hibernate");
			course.setTraineeList(traineeList);
			courseList.add(course);
			
			if(dao.addTraineeCourse(traineeList, courseList))
			{
				System.out.println("Success");
			}
			else
			{
				System.out.println("Failed");
			}
*/
		/*	Room room = new Room();
			room.setRoomName("R23");
			Event event = new Event();
			event.setEventName("Hibernate");
			
			if(dao.addRoomEvent(room, event))
			{
				System.out.println("Success");
			}
			else
			{
				System.out.println("Failed");
			}
*/
			Room room = new Room();
			room.setRoomName("R25");
			List<Participant> pList = new ArrayList<Participant>();
			Participant p1;
			p1= new Participant();
			p1.setParticipantName("Hari");
			p1.setRoom(room);
			pList.add(p1);
			p1 = new Participant();
			p1.setParticipantName("Sree");
			p1.setRoom(room);
			pList.add(p1);
			if(dao.addParticipants(room, pList))
			{
				System.out.println("Success");
			}
			else
			{
				System.out.println("Failure");
			}
			
			
	}

}
