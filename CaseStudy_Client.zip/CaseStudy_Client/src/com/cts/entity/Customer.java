package com.cts.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;


//import com.cts.EventMaster;


public class Customer{	
	
	protected int custId;

	protected String custName;
	protected String custAddress;

	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	
		
}
