package com.cognizant.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.cognizant.entities.Employee;
import com.sun.org.apache.bcel.internal.generic.NEW;

@Path("/DateConverter")
public class DateConverterService {

	@GET
	@Path("/Format/{year}/{month}/{day}")
	public Response formatDate(@PathParam("year") int year,@PathParam("month") int month,@PathParam("day") int day)
	{
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MMM/dd");
		Date date = new Date(year-1900,month-1,day);
		String formatedDate = sdf.format(date);
		
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600")
				.entity(formatedDate)
				.build();

	}
	
	//EmployeeInfo?EmployeeId=360654&Name="Ananthi"&SkillSet="Java"&SkillSet="DotNet"&SkillSet="Python"
	@GET
	@Path("/EmployeeInfo")
	
	public Response getEmployeeInfo(@QueryParam("EmployeeId") int EmployeeId,
							@QueryParam("Name") String Name, 
							@QueryParam("SkillSet") List<String> SkillSet)
	{
		
		/*Properties prop = new Properties();
		prop.put("EmployeeId", EmployeeId);
		prop.put("Name", Name);
		prop.put("SkillSet",SkillSet);
		*/
		
		Employee emp = new Employee();
		emp.setEmployeeId(EmployeeId);
		emp.setName(Name);
		emp.setSkillSet(SkillSet);
		
		
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600")
				.entity(emp)
				.build();
	}
}
