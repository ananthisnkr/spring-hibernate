package com.cognizant.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;






import com.cognizant.dao.CustomerManager;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Message;

@Path("/CustomerService")
public class CustomerService {

	@POST
	@Path("/AddCustomer")
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response addCustomerService(Customer customer)
	{
		System.out.println("service  "+customer.getCustomerId());
		System.out.println(customer.getName());
		boolean status = CustomerManager.addCustomer(customer);
		Message msg = new Message();
		msg.setStatus("Not Added");
		if(status)
		{
			msg.setStatus("Record Added");
		}
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600")
				.entity(msg)
				.build();
	}
	
	@GET
	@Path("/GetCustomers")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response getAllService()
	{
//Converting collection to json
		
		GenericEntity<List<Customer>> genentity = new 
				GenericEntity<List<Customer>>(CustomerManager.getAll()){};
				return Response.status(200)
						.header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
						.header("Access-Control-Allow-Credentials", "true")
						.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
						.header("Access-Control-Max-Age","1209600")
						.entity(genentity)
						.build();
	
	}
	@GET
//	@Path("/CustomerById/{customerId}")
	@Path("/CustomerById/{customerId:\\d+}")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response getCustomerById(@PathParam("customerId")int customerId)
	{
		Customer customer = CustomerManager.getCustomerById(customerId);
				return Response.status(200)
						.header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
						.header("Access-Control-Allow-Credentials", "true")
						.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
						.header("Access-Control-Max-Age","1209600")
						.entity(customer)
						.build();
	
	}
}
