package com.cognizant.services;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.cognizant.entities.Message;

@Path("/ProductService")
public class ProductService {

	@POST
	@Path("/AddProduct")
	public Response addProduct(@FormParam("productId") int Id,@FormParam("name") String Name)
	{

		Message msg = new Message();
		if((Id>0) && (Name !=null))
		{
			msg.setStatus("Received Data = "+Id+"\t"+Name);
		}
		else 
		{
			msg.setStatus("Not Received");
		}
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", "true")
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600")
				.entity(msg)
				.build();

	}
	
}
