package com.cognizant.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Customer;
import com.cognizant.resources.HibernateUtil;

public class CustomerManager {

	private static SessionFactory factory;
	private static Session session;
	private static boolean status;
	
	
	
	public static boolean addCustomer(Customer customer)
	{
		factory = HibernateUtil.GetFactory();
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			System.out.println("in dao: "+customer.getCustomerId());
			System.out.println("in dao: "+customer.getName());
			session.save(customer);
			session.getTransaction().commit();
			status = true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public static List<Customer> getAll()
	{
		factory = HibernateUtil.GetFactory();
		session = factory.openSession();
		return session.createQuery("from Customer").list();
	}
	public static Customer getCustomerById(int customerId)
	{
		factory = HibernateUtil.GetFactory();
		session = factory.openSession();
		Customer customer = (Customer) session.get(Customer.class, customerId);
		session.close();
		return customer;
	}
}
