package com.cognizant.entities;

public class NewCustomer extends Customer{

	
}
