package com.cognizant.entities;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Booking_Master")
public class Booking {

	//@AttributeOverride(name="customer", column=@Column(name="Customer_ID"))
	@EmbeddedId
	private BookingC bookingId;

	@Column(name="Tickets_Booked")
	private int ticketsBooked;
	
	@Column(name="Amount")
	private int amount;

	public BookingC getBookingId() {
		return bookingId;
	}

	public void setBookingId(BookingC bookingId) {
		this.bookingId = bookingId;
	}

	public int getTicketsBooked() {
		return ticketsBooked;
	}

	public void setTicketsBooked(int ticketsBooked) {
		this.ticketsBooked = ticketsBooked;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
}
