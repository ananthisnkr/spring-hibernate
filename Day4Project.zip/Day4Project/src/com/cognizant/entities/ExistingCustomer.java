package com.cognizant.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Existing_Customer")
public class ExistingCustomer extends Customer {

}
