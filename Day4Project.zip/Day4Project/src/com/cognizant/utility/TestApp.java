package com.cognizant.utility;

import com.cognizant.dao.BookingDao;
import com.cognizant.entities.Location;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BookingDao dao = new BookingDao();
		System.out.println(dao.getLocationCount());
		
		
		System.out.println(dao.getMaxLocationId());
	//	System.out.println(dao.getLocationByName("MEPZ"));
		/*System.out.println(dao.sortLocation());
		
		for(Location loc : dao.sortLocation()){
			System.out.println(loc.getLocationName());
		}
		*/
	/*	System.out.println(dao.getSecondMaxLocationId());
		Location loc = dao.getLocationByName("MEPZ");
		System.out.println(loc.getLocationId());
	*/	
		for(Location loc :dao.getLocationByName("MEPZ"))
		{
			System.out.println(loc.getLocationId());
		}
	}

}
