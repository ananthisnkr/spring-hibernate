package com.cognizant.tests;

import static org.junit.Assert.*;

import java.awt.Label;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.dao.BookingDao;
import com.cognizant.entities.Location;

public class EventManagementTest {

	BookingDao bdao;
	@Before
	public void setUp() throws Exception {
		bdao = new BookingDao();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		//fail("Not yet implemented");
		
		/*Location loc = new Location();
		loc.setLocationName("MEPZ");
		assertTrue(bdao.insertLocationData(loc)>0);
		
		*/
	//	assertTrue(bdao.insertLocations());
		
		assertNotNull(bdao.getLocationByName("MEPZ"));
		
		
	}

}
