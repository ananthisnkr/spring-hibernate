package com.cognizant.dao;

import java.util.List;
import java.util.Random;







import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cognizant.entities.Booking;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Event;
import com.cognizant.entities.Location;
import com.cognizant.resources.HibernateUtil;

public class BookingDao {

	private SessionFactory factory;
	private Session session;
	
	private Location location;
	private Event event;
	private Booking booking;
	private Customer customer;
	
	public BookingDao()
	{
		factory = HibernateUtil.GetFactory();
	}
	
	public int insertLocationData(Location loc)
	{
		location =loc;
		int pk=0;
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			pk = (int) session.save(location);
			session.getTransaction().commit();
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		return pk;
	}
	
	public void insertEventData(Event eve, int locId)
	{
		event = eve;
		session = factory.openSession();
		session.beginTransaction();
		try
		{
			Location result = (Location) session.get(Location.class, locId);
			eve.setLoc(result);
			session.persist(eve);
			session.getTransaction().commit();
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
	}

	public boolean insertLocations()
	{
		boolean status = false;
		
		session = factory.openSession();
		session.beginTransaction();
		Random random = new Random(1000);
		Location location = null;
		try{
			

			for(int i=0;i<100;i++){
				location = new Location();
				location.setLocationName("CTS "+random.nextInt());
				session.save(location);
				if(i%20==0)
				{
					session.flush();
					session.clear();
					
				}
			}
			session.getTransaction().commit();
			status= true;
		}
		catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		
		
		return status;
		
	}


	public List<Location> getLocationByName(String name)
	{
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		//Query query = session.createQuery("from Location where locationName=?");
		//Query query = session.getNamedQuery("getLocationByName");
		
		Criteria criteria = session.createCriteria(Location.class);
		criteria.add(Restrictions.gt("locationId", 50));
		return criteria.list();
		
		/*
		query.setParameter(0, name);
		return (Location) query.list().get(0);
*/	}
	
	public long getLocationCount()
	{
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		Query query = session.createQuery("select count(loc.locationName) from Location loc");
		return (long) query.list().get(0);
	}
	
	public int getMaxLocationId()
	{
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		Query query = session.createQuery("select max(loc.locationId) from Location loc");
		return (int) query.list().get(0);
	}
	
	public List<Location> sortLocation()
	{
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		Query query = session.createQuery("from Location loc order by loc.locationName desc");
		return  query.list();
	}
	
	public int getSecondMaxLocationId()
	{
		factory=HibernateUtil.GetFactory();
		session = factory.openSession();
		Query query = session.createQuery("select max(l.locationId) from Location l where l.locationId < "
				+ "(select max(loc.locationId) from Location loc)");
		return (int) query.list().get(0);
	}
	
}
